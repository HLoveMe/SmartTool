import { fetchInterval, fetchTimely } from './fetch';
import BlockFetch from './BlockFetch';
import { theWeek } from './theWeek';

export {
  fetchInterval,
  fetchTimely,
  BlockFetch,
  theWeek,
};
